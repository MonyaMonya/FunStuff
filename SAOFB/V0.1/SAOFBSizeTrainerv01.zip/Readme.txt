Sword Art Online: Fatal Bullet Trainer v.0.1
--------------------------------------------
For use only on 64 bit version of the game. No guarantees that it'll work. Originally made on a windows 10 system.

Use:
----
First off, Sword Art Online: Fatal Bullet uses EAC to prevent cheating. You'll have to disable it if you want to use this trainer. There's several guides online on how to do it, but I've included the launcher program that most utilize. You put that into your Sword Art Online directory in steam (steamapps/common/yourname/Sword Art Online Fatal Bullet) and running it will stop EAC from being loaded. You may need to uninstall EAC in order to get it to work. This may affect other games, and it'll definitely prevent you from playing online in SAO:FB.

Secondly, open the game and go to one of the character customization screens. Here you can alt tab out and open up the trainer. When in the character customization screen, you can press the 'Enable' button to turn on the trainer and load the scale/slider values. Then you'll just change the values to be what you want and hit 'Apply'. After applying, you need to change a slider value on the game in order for the changes to visually appear. This will overwrite whatever you input though. I'd suggest changing something you don't care about, like Hand Size or Head Size. The numbers on the screen won't change, but the appearance should match what you input. You can Disable the form again after you're done, though this is just in case you want to switch characters to reload it.

The scale value is a percentile tacked onto 100% that will affect player height. So 0.25 would mean the character model would be scaled up to 125%. The rest of the slider values range from -10 to 10. If you want to go higher or lower, you need to hit the "Disable Slider Boundaries" button. I'd suggest re-enabling it after you're done though, I've seen the game crash after saving/exiting without re-enabling those boundaries.

Limitations:
------------
-Saving seems to work for the scale, but not for the slider values that go above 10 or below -10.
-There seem to be 2 models used in-game: one for cutscenes and some hub-world activities, and one for gameplay. This trainer affects the cutscene one, and while some changes do carry over, it seems the scaling is capped to 300% overall and the slider values are locked between -10 and 10.
-I've never seen what happens with an overall negative scale value (like < -1.0). The game could possibly crash.